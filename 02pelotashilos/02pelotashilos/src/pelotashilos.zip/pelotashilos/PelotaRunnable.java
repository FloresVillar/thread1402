package pelotashilos;
import java.awt.*;

public class PelotaRunnable implements Runnable{

    private Pelota pelota;
    private Component componente;
    public static final int PASOS =1000;
    public static final int RETARDO =5;


    public PelotaRunnable(Pelota unaPelota, Component unComponente){
        pelota = unaPelota;
        componente = unComponente;
    }

    public void run(){
        try{
            for(int i=1; i<=PASOS; i++){
                pelota.mover(componente.getBounds());
                componente.repaint();
                Thread.sleep(RETARDO);
            }

        }catch(InterruptedException e){

        }

    }


}
